package com.example;

import android.app.Application;

public class DeckardApplication extends Application {

}
